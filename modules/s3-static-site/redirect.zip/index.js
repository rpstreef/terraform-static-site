'use strict';

exports.handler = (event, context, callback) => {
  const request = event.Records[0].cf.request;
  const uri = request.uri;

  if (uri.endsWith('/')) {
    request.uri += 'index.html';
  } else if (!uri.includes('.')) {
    request.uri += '/index.html';
  }

  // Route the request to a resource which is known not to exist.
  if (URL_IS_FORBIDDEN) {
    // NULL doesn't exist at the origin, so it will 403/404.
    request.uri = '/NULL';
  } 

  return callback(null, request);
};
